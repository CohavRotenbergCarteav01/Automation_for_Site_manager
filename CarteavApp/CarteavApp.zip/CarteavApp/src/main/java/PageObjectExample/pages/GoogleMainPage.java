package PageObjectExample.pages;

public class GoogleMainPage {

}
