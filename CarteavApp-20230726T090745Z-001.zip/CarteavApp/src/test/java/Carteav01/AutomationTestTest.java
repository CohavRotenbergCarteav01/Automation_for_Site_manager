package Carteav01;

import org.openqa.selenium.chrome.ChromeDriver;

import static org.junit.jupiter.api.Assertions.*;

class AutomationTestTest extends seleniumBase {
    public static void main(String[] args) {
        ChromeDriver driver;
        driver.get("https://manager.carteav.com/login");
        driver = testStart(url);

        public void fillFieldTest (); {


            driver.findElement(By.id("outlined-adornment-userName")).sendKeys("alon");

            // Click a button
            driver.findElement(By.id("buttonId")).click();
        }

    }

}